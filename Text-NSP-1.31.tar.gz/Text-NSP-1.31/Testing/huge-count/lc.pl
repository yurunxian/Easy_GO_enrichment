#!/usr/local/bin/perl

while(<>)
{
	tr/[A-Z]/[a-z]/;
	print;
}
